do

local function run(msg, matches)
if matches[1]=="nerkh" and is_sudo(msg) then 
return  [[🌟*Shield Power Nerkh List*🌟

👑 _آنتی اسپم برای سوپرگروه با تمام امکانات :_ 👑

⭐ _گروه 1 ماهه *5000* تومان_ 💰

🏆 _گروه 3 ماهه *15000* تومان_ 💰

👑 _گروه نامحدود *25000* تومان_ 💰

➖➖➖➖➖➖➖➖➖➖➖

💳 _شماره حساب برای کسانی که از عابربانک پرداخت می کنند :_

📟 *6037-6915-7093-8928*

👤 _محمد امین صمدی_
 
  🏦 _بانک صادرات_

➖➖➖➖➖➖➖➖➖➖➖

🌍 _یا از طریق درگاه بانکی ما برای کسانی که کارت بانکیشان رمز دوم دارد به آدرس پرداخت نمایند :_

🏧 https://idpay.ir/pedi-shield

♊️♊️♊️♊️♊️♊️♊️♊️♊️♊️♊️

➣ ♈️️️вΦƮ vęЯsiΦП ••• V 4.0♈️

➣ 👑SHIELD™POWER👑

➣ 🆔 _Channel ™ :_ @ShieldTeamS

*_🇸 __🇭__🇮__🇪__🇱__🇩_*

=======================
🇸 🇭 🇮 🇪 🇱 🇩™]]
end

end

return {
  patterns = {
    "^[!/#]([Nn]erkh)$",
    },
  run = run
}
end



--by #SDP Team
--by Editor @Xx_KinG_SuPeR_AdMiN_SHIELD_xX
--Channel ™ : @Shield_Tm

