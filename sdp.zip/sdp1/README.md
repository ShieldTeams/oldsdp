# [Shield Power](https://telegram.me/Xx_ShielD_PoweR_xX)

**An advanced and powerful administration bot based on NEW TG-CLI


* * *

## Commands

| Use help |
|:--------|:------------|
| [#!/]help | just send help in your group and get the commands |

**You can use "#", "!", or "/" to begin all commands

* * *

# Installation

```sh
# Let's install the bot.
cd $HOME
git clone https://github.com/ShieldTeams/SDP.git
cd SDP
chmod +x sdp.sh
./sdp.sh install
./sdp.sh 
# Enter a phone number & confirmation code.

# For Auto Launch:
chmod 777 autosdp.sh
screen ./autosdp.sh
```
### One command
To install everything in one command, use:
```sh
cd $HOME && git clone https://github.com/ShieldTeams/SDP.git && cd SDP && chmod +x sdp.sh && ./sdp.sh install && ./sdp.sh

OR

cd $HOME && git clone https://github.com/ShieldTeams/SDP.git && cd SDP && chmod +x sdp.sh && ./sdp.sh install && chmod 777 autosdp.sh && screen ./autosdp.sh
```

* * *

# Support and Development

More information [Shield Global Chat](https://t.me/joinchat/AAAAAEKRtuWF22uMOmflyQ)

# Special thanks to

[@EMlNEM](https://telegram.me/EMlNEM)

[@SoLiD021](https://telegram.me/SoLiD021)

[@pv_unknown](https://telegram.me/pv_unknown)

* * *

# Developers!

[Pedi Shield]([Telegram](https://telegram.me/Xx_KinG_SuPeR_AdMiN_SHIELD_xX))

[Hidden Shield]([Telegram](https://telegram.me/Xx_PesareShield_shah2Arvah_xX))


### Our Telegram channel:

[@ShieldTeamS](https://telegram.me/ShieldTeamS)


### Our Link Shield Team:

[www.ShieldTeam.ir](http://‌ShieldTeam.ir)
